Starcraft - Menus, Images, and General Extractions
Extracted and converted into modern image formats by ACE_Spark.
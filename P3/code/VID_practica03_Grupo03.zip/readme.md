README
  Readme del grupo 3 de la asignatura de videojuegos para la tercera práctica
  que trata sobre el shading de Phong, el environment mapping, y el normal
  mapping

AUTHORS
  Alexandre Zheng - 776093
  Alonso del Rincón - 783252
  Antonio Gallén - 735184
  Juan Plo - 795105

DESCRIPTION
  -VID_practica03_Grupo03.zip/
  |-envMapping.html
  |-normalMapping.html
  |-phong.html
  |-readme.md //este fichero

CONTRIBUTING
  Alexandre Zheng:    12 horas
  Alonso del Rincón:  13 horas
  Antonio Gallén:     13 horas
  Juan Plo:           12 horas
  Total:              50 horas
